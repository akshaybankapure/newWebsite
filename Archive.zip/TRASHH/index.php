<?php
// Start session
session_start();

// Include necessary files
require_once 'includes/db-connect.php';
require_once 'includes/functions.php';

// Get the requested page from the URL
$requestedPage = $_GET['page'] ?? 'home';

// Sanitize the input to prevent potential security issues
$requestedPage = filter_var($requestedPage, FILTER_SANITIZE_STRING);

// Get page data from the database
$pageData = getPageContent($requestedPage);

// If page doesn't exist, show 404 page
if (!$pageData) {
    header("HTTP/1.0 404 Not Found");
    $pageData = getPageContent('404');
    if (!$pageData) {
        die('Page not found');
    }
}

// Get the template for this page
$template = $pageData['template'] ?? 'default';

// Get the style for this page
$styleFile = getPageStyle($pageData['id']);

// Start output buffering
ob_start();

// Include the header
include 'includes/header.php';

// Include the appropriate template file
if (file_exists("templates/{$template}.php")) {
    include "templates/{$template}.php";
} else {
    include "templates/default.php";
}

// Include the footer
include 'includes/footer.php';

// End output buffering and flush output
ob_end_flush();

/**
 * Function to get page content from the database
 */
function getPageContent($slug) {
    global $db;
    $query = "SELECT * FROM pages WHERE slug = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Function to get page style from the database
 */
function getPageStyle($pageId) {
    global $db;
    $query = "SELECT styles.css_file FROM styles JOIN pages ON styles.id = pages.style_id WHERE pages.id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $pageId);
    $stmt->execute();
    $result = $stmt->get_result();
    $style = $result->fetch_assoc();
    return $style ? $style['css_file'] : 'default.css';
}
?>