<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

include 'config.php';

// Fetch all menu items
$sql = "SELECT * FROM menu_items ORDER BY parent_id, id";
$result = $conn->query($sql);

$menuItems = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $menuItems[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/admin_style.css">
</head>
<body>
    <div class="dashboard-container">
        <h2>Admin Dashboard</h2>
        <a href="admin_add_menu_item.php">Add New Menu Item</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Parent ID</th>
                    <th>Title</th>
                    <th>Link</th>
                    <th>Active</th>
                    <th>Has Children</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($menuItems as $item): ?>
                    <tr>
                        <td><?php echo $item['id']; ?></td>
                        <td><?php echo $item['parent_id']; ?></td>
                        <td><?php echo $item['title']; ?></td>
                        <td><?php echo $item['link']; ?></td>
                        <td><?php echo $item['is_active'] ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $item['has_children'] ? 'Yes' : 'No'; ?></td>
                        <td>
                            <a href="admin_edit_menu_item.php?id=<?php echo $item['id']; ?>">Edit</a>
                            <a href="admin_delete_menu_item.php?id=<?php echo $item['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="admin_logout.php">Logout</a>
    </div>
</body>
</html>
