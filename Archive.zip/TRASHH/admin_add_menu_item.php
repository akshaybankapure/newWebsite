<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $parent_id = $_POST['parent_id'] ?: NULL;
    $title = $_POST['title'];
    $link = $_POST['link'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $has_children = isset($_POST['has_children']) ? 1 : 0;

    $sql = "INSERT INTO menu_items (parent_id, title, link, is_active, has_children) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issii", $parent_id, $title, $link, $is_active, $has_children);
    $stmt->execute();

    header('Location: admin_dashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Menu Item</title>
    <link rel="stylesheet" href="css/admin_style.css">
</head>
<body>
    <div class="form-container">
        <h2>Add New Menu Item</h2>
        <form method="post">
            <div class="form-group">
                <label for="parent_id">Parent ID:</label>
                <input type="number" id="parent_id" name="parent_id">
            </div>
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="link">Link:</label>
                <input type="text" id="link" name="link" required>
            </div>
            <div class="form-group">
                <label for="is_active">Active:</label>
                <input type="checkbox" id="is_active" name="is_active">
            </div>
            <div class="form-group">
                <label for="has_children">Has Children:</label>
                <input type="checkbox" id="has_children" name="has_children">
            </div>
            <button type="submit">Add</button>
        </form>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
