<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

include 'config.php';

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $parent_id = $_POST['parent_id'] ?: NULL;
    $title = $_POST['title'];
    $link = $_POST['link'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $has_children = isset($_POST['has_children']) ? 1 : 0;

    $sql = "UPDATE menu_items SET parent_id = ?, title = ?, link = ?, is_active = ?, has_children = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issiii", $parent_id, $title, $link, $is_active, $has_children, $id);
    $stmt->execute();

    header('Location: admin_dashboard.php');
    exit;
}

$sql = "SELECT * FROM menu_items WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$item = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Menu Item</title>
    <link rel="stylesheet" href="css/admin_style.css">
</head>
<body>
    <div class="form-container">
        <h2>Edit Menu Item</h2>
        <form method="post">
            <div class="form-group">
                <label for="parent_id">Parent ID:</label>
                <input type="number" id="parent_id" name="parent_id" value="<?php echo $item['parent_id']; ?>">
            </div>
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" value="<?php echo $item['title']; ?>" required>
            </div>
            <div class="form-group">
                <label for="link">Link:</label>
                <input type="text" id="link" name="link" value="<?php echo $item['link']; ?>" required>
            </div>
            <div class="form-group">
                <label for="is_active">Active:</label>
                <input type="checkbox" id="is_active" name="is_active" <?php echo $item['is_active'] ? 'checked' : ''; ?>>
            </div>
            <div class="form-group">
                <label for="has_children">Has Children:</label>
                <input type="checkbox" id="has_children" name="has_children" <?php echo $item['has_children'] ? 'checked' : ''; ?>>
            </div>
            <button type="submit">Save</button>
        </form>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
