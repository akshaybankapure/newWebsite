/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { RGBELoader } from 'three/examples/jsm/loaders/RGBELoader.js';

export const useThree = (mountRef: React.RefObject<HTMLDivElement>) => {
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const controlsRef = useRef<PointerLockControls | null>(null);
    const fbxLoader = new FBXLoader();
    const gltfLoader = new GLTFLoader();
    const textureLoader = new THREE.TextureLoader();
    const moveForward = useRef(false);
    const moveBackward = useRef(false);
    const moveLeft = useRef(false);
    const moveRight = useRef(false);
    const moveUp = useRef(false);
    const moveDown = useRef(false);

    useEffect(() => {
        if (!mountRef.current) return;

        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.lookAt(5, 2.6, -5);
        camera.position.set(-22, 3.6, 10);
        cameraRef.current = camera;

        const renderer = new THREE.WebGLRenderer({ antialias: true }) as any;
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        renderer.physicallyCorrectLights = true; // Improve shader quality
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.25;
        mountRef.current.appendChild(renderer.domElement);

        // Load HDR Environment
        new RGBELoader()
            .load('/models/sky_hdr/HDR_029_Sky_Cloudy_Ref.hdr', (texture) => {
                texture.mapping = THREE.EquirectangularReflectionMapping;
                scene.background = texture;
                scene.environment = texture;
            });

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.2);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(155, 25, 157);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 2048; // Increase shadow quality
        directionalLight.shadow.mapSize.height = 2048;
        scene.add(directionalLight);

        const spotLight = new THREE.SpotLight(0xffffff, 0.5);
        spotLight.position.set(-15, 25, -5);
        spotLight.castShadow = true;
        spotLight.shadow.mapSize.width = 2048; // Increase shadow quality
        spotLight.shadow.mapSize.height = 2048;
        scene.add(spotLight);

        const planeTexture = textureLoader.load('/models/plane/wood_cabinet_worn_long_diff_4k.jpg');
        const planeGeometry = new THREE.PlaneGeometry(100, 100);
        const planeMaterial = new THREE.MeshStandardMaterial({ map: planeTexture });
        const plane = new THREE.Mesh(planeGeometry, planeMaterial);
        plane.rotation.x = -Math.PI / 2;
        plane.position.y = 0;
        plane.receiveShadow = true;
        scene.add(plane);

        // const loadModel = (modelPath: string, texturePaths: string[], position: THREE.Vector3, scale: number, rotation: THREE.Euler) => {
        //     fbxLoader.load(modelPath, (object: any) => {
        //         object.position.copy(position);
        //         object.scale.set(scale, scale, scale);
        //         object.rotation.copy(rotation); // Set the rotation
        //         object.traverse((child: any) => {
        //             if (child instanceof THREE.Mesh) {
        //                 const texturePromises = texturePaths.map(path => textureLoader.loadAsync(path));
        //                 Promise.all(texturePromises).then(textures => {
        //                     const material = new THREE.MeshStandardMaterial({
        //                         map: textures[0],
        //                         roughnessMap: textures[3],
        //                         metalnessMap: textures[1],
        //                         normalMap: textures[2],
        //                     });
        //                     child.material = material;
        //                     child.castShadow = true;
        //                     child.receiveShadow = true;
        //                 });
        //             }
        //         });
        //         scene.add(object);
        //     });
        // };
        // const rotationY = new THREE.Euler(0, Math.PI, 0);
        // // Load Modern Furniture
        // loadModel(
        //     '/models/movel_moderno/movel_moderno.fbx',
        //     [
        //         '/models/movel_moderno/lambert1_Base_Color.png',
        //         '/models/movel_moderno/lambert1_Metallic.png',
        //         '/models/movel_moderno/lambert1_Normal_DirectX.png',
        //         '/models/movel_moderno/lambert1_Roughness.png',
        //     ],
        //     new THREE.Vector3(2.9, 0, 6.8),
        //     1,
        //     rotationY
        // );
        const loadHouseModel = (houseModelPath: string, position: THREE.Vector3, scale: number): Promise<THREE.Group> => {
            return new Promise((resolve, reject) => {
                gltfLoader.load(houseModelPath, (gltf) => {
                    const house = gltf.scene;
                    house.position.copy(position);
                    house.scale.set(scale, scale, scale);
                    house.traverse((child: any) => {
                        if (child instanceof THREE.Mesh) {
                            child.castShadow = true;
                            child.receiveShadow = true;
                        }
                    });
                    scene.add(house);
                    resolve(house);
                }, undefined, reject);
            });
        };
        
        const loadObjectInsideHouse = (
            objectModelPath: string,
            position: THREE.Vector3,
            scale: number,
            parent: THREE.Group,
            rotate: THREE.Euler
        ): Promise<THREE.Group> => {
            return new Promise((resolve, reject) => {
                gltfLoader.load(objectModelPath, (gltf) => {
                    const object = gltf.scene;
                    object.position.copy(position);
                    object.rotation.copy(rotate); // Set the rotation
                    object.scale.set(scale, scale, scale);
                    object.traverse((child: any) => {
                        if (child instanceof THREE.Mesh) {
                            child.castShadow = true;
                            child.receiveShadow = true;
                        }
                    });
                    parent.add(object);
                    resolve(object);
                }, undefined, reject);
            });
        };
        const rotationY = new THREE.Euler(0, Math.PI/2, 0);
        const noRotation = new THREE.Euler(0, 0, 0);
        // Load the house
        loadHouseModel('/models/cottage/teahouse.glb', new THREE.Vector3(0, -0.1, 0), 0.3).then((house: THREE.Group) => {
            house.rotation.y = Math.PI / -2;
            // Load objects inside the housew
            loadObjectInsideHouse('/models/sofa_low/sofa_low.glb', new THREE.Vector3(-1, 1, 15), 5, house, rotationY);
            loadObjectInsideHouse('/models/cottage/tv_unit.glb', new THREE.Vector3(3, -1, 1), 1, house, noRotation);
        });
        
        const loadGLModel = (modelPath: string, position: THREE.Vector3, scale: number): Promise<THREE.Group> => {
            return new Promise((resolve, reject) => {
                gltfLoader.load(modelPath, (gltf) => {
                    const object = gltf.scene;
                    object.position.copy(position);
                    object.scale.set(scale, scale, scale);
                    object.traverse((child: any) => {
                        if (child instanceof THREE.Mesh) {
                            child.castShadow = true;
                            child.receiveShadow = true;
                        }
                    });
                    scene.add(object);
                    resolve(object);
                }, undefined, reject);
            });
        };

        // Load Car
        loadGLModel(
            '/models/cars/ferrari_sf90_stradale.glb',
            new THREE.Vector3(-23, 0, -7),
            3
        ).then((cottage: THREE.Group) => {
            cottage.rotation.y = Math.PI/5;
        });

        // Load Additional Characters (Examples)
        loadGLModel(
            '/models/animated/hero_alice_lobby.glb',
            new THREE.Vector3(-11, 0, -15),
            2
        );
        // const mixer = new THREE.AnimationMixer(model);
        // const action = mixer.clipAction(animations[0]);
        // action.play();

        
        loadGLModel(
            '/models/cottage/lowpoly_tree.glb',
            new THREE.Vector3(-16, 0, -10),
            1
        );

        // loadGLModel(
        //     '/models/character2/character2.gltf',
        //     new THREE.Vector3(-5, 0, -5),
        //     1
        // );

        controlsRef.current = new PointerLockControls(camera, mountRef.current);
        mountRef.current.addEventListener('click', () => {
            controlsRef.current?.lock();
        });

        const handleResize = () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        };
        window.addEventListener('resize', handleResize);

        const handleKeyDown = (event: KeyboardEvent) => {
            switch (event.code) {
                case 'KeyW':
                    moveForward.current = true;
                    break;
                case 'KeyA':
                    moveLeft.current = true;
                    break;
                case 'KeyS':
                    moveBackward.current = true;
                    break;
                case 'KeyD':
                    moveRight.current = true;
                    break;
                case 'ArrowUp':
                    moveUp.current = true;
                    break;
                case 'ArrowDown':
                    moveDown.current = true;
                    break;
            }
        };

        const handleKeyUp = (event: KeyboardEvent) => {
            switch (event.code) {
                case 'KeyW':
                    moveForward.current = false;
                    break;
                case 'KeyA':
                    moveLeft.current = false;
                    break;
                case 'KeyS':
                    moveBackward.current = false;
                    break;
                case 'KeyD':
                    moveRight.current = false;
                    break;
                case 'ArrowUp':
                    moveUp.current = false;
                    break;
                case 'ArrowDown':
                    moveDown.current = false;
                    break;
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        document.addEventListener('keyup', handleKeyUp);

        const animate = () => {
            if (controlsRef.current) {
                const moveSpeed = 0.05;
                const strafeSpeed = 0.01;

                if (moveForward.current) controlsRef.current.moveForward(moveSpeed);
                if (moveBackward.current) controlsRef.current.moveForward(-moveSpeed);
                if (moveLeft.current) controlsRef.current.moveRight(-strafeSpeed);
                if (moveRight.current) controlsRef.current.moveRight(strafeSpeed);
                if (moveUp.current) camera.position.y += moveSpeed;
                if (moveDown.current) camera.position.y -= moveSpeed;
            }

            renderer.render(scene, camera);
            requestAnimationFrame(animate);
        };
        animate();

        return () => {
            mountRef.current?.removeChild(renderer.domElement);
            window.removeEventListener('resize', handleResize);
            document.removeEventListener('keydown', handleKeyDown);
            document.removeEventListener('keyup', handleKeyUp);
        };
    }, [mountRef]);

    return { cameraRef };
};
