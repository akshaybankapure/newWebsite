/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

export const useThree = (mountRef: React.RefObject<HTMLDivElement>) => {
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const controlsRef = useRef<PointerLockControls | null>(null);
    const fbxLoader = new FBXLoader();
    const gltfLoader = new GLTFLoader();
    const textureLoader = new THREE.TextureLoader();
    const PlanetextureLoader = new THREE.TextureLoader();
    const moveForward = useRef(false);
    const moveBackward = useRef(false);
    const moveLeft = useRef(false);
    const moveRight = useRef(false);
    const moveUp = useRef(false);
    const moveDown = useRef(false);

    useEffect(() => {
        if (!mountRef.current) return;

        // Scene setup
        const scene = new THREE.Scene();

        // Camera setup
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.lookAt(5, 1.6, 3);
        camera.position.set(0, 1.6, 10); // Eye level
        cameraRef.current = camera;

        // Renderer setup
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true; // Enable shadow map
        renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Soft shadows
        mountRef.current.appendChild(renderer.domElement);

        // Lighting setup
        const ambientLight = new THREE.AmbientLight(0xffffff, 2);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(5, 10, 7.5);
        directionalLight.castShadow = true; // Enable shadow casting
        directionalLight.shadow.mapSize.width = 1024;
        directionalLight.shadow.mapSize.height = 1024;
        scene.add(directionalLight);

        const spotLight = new THREE.SpotLight(0xffffff, 0.5);
        spotLight.position.set(-5, 10, -5);
        spotLight.castShadow = true; // Enable shadow casting
        spotLight.shadow.mapSize.width = 1024;
        spotLight.shadow.mapSize.height = 1024;
        scene.add(spotLight);

        // Ground plane setup
        const planeTexture = PlanetextureLoader.load('/models/plane/flour_ao_4k.jpg');
        const planeGeometry = new THREE.PlaneGeometry(100, 100);
        const planeMaterial = new THREE.MeshStandardMaterial({ map: planeTexture });
        const plane = new THREE.Mesh(planeGeometry, planeMaterial);
        plane.rotation.x = -Math.PI / 2;
        plane.position.y = 0;
        plane.receiveShadow = true; // Enable shadow receiving
        scene.add(plane);

        // Load models and textures
        const loadModel = (modelPath: string, texturePaths: string[], position: THREE.Vector3, scale: number) => {
            fbxLoader.load(modelPath, (object: any) => {
                object.position.copy(position);
                object.scale.set(scale, scale, scale);

                // Apply textures
                object.traverse((child: any) => {
                    if (child instanceof THREE.Mesh) {
                        const texturePromises = texturePaths.map(path => textureLoader.loadAsync(path));
                        Promise.all(texturePromises).then(textures => {
                            const material = new THREE.MeshStandardMaterial({
                                map: textures[0], // Base color texture
                                roughnessMap: textures[3], // Roughness texture
                                metalnessMap: textures[1], // Metallic texture
                                normalMap: textures[2], // Normal map
                            });
                            child.material = material;
                            child.castShadow = true; // Enable shadow casting
                            child.receiveShadow = true; // Enable shadow receiving
                        });
                    }
                });
                scene.add(object);
            });
        };

        loadModel(
            '/models/movel_moderno/movel_moderno.fbx',
            [
                '/models/movel_moderno/lambert1_Base_Color.png',
                '/models/movel_moderno/lambert1_Metallic.png',
                '/models/movel_moderno/lambert1_Normal_DirectX.png',
                '/models/movel_moderno/lambert1_Roughness.png',
            ],
            new THREE.Vector3(10, 0, 0),
            1
        );

        const loadGLModel = (modelPath: string, position: THREE.Vector3, scale: number): Promise<THREE.Group> => {
            return new Promise((resolve, reject) => {
                gltfLoader.load(modelPath, (gltf) => {
                    const object = gltf.scene;
                    object.position.copy(position);
                    object.scale.set(scale, scale, scale);
                    object.traverse((child: any) => {
                        if (child instanceof THREE.Mesh) {
                            child.castShadow = true; // Enable shadow casting
                            child.receiveShadow = true; // Enable shadow receiving
                        }
                    });
                    scene.add(object);
                    resolve(object);
                }, undefined, reject);
            });
        };

        loadGLModel(
            '/models/sofa_low/sofa_low.glb',
            new THREE.Vector3(12.1, 0, 5),
            1
        ).then((sofa: THREE.Group) => {
            sofa.rotation.y = Math.PI / 2; // Rotate by 90 degrees
        });

        // Pointer Lock API for smooth mouse movement
        controlsRef.current = new PointerLockControls(camera, mountRef.current);
        mountRef.current.addEventListener('click', () => {
            controlsRef.current?.lock();
        });

        const handleResize = () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        };
        window.addEventListener('resize', handleResize);

        const handleKeyDown = (event: KeyboardEvent) => {
            switch (event.code) {
                case 'KeyW':
                    moveForward.current = true;
                    break;
                case 'KeyA':
                    moveLeft.current = true;
                    break;
                case 'KeyS':
                    moveBackward.current = true;
                    break;
                case 'KeyD':
                    moveRight.current = true;
                    break;
                case 'ArrowUp':
                    moveUp.current = true;
                    break;
                case 'ArrowDown':
                    moveDown.current = true;
                    break;
            }
        };

        const handleKeyUp = (event: KeyboardEvent) => {
            switch (event.code) {
                case 'KeyW':
                    moveForward.current = false;
                    break;
                case 'KeyA':
                    moveLeft.current = false;
                    break;
                case 'KeyS':
                    moveBackward.current = false;
                    break;
                case 'KeyD':
                    moveRight.current = false;
                    break;
                case 'ArrowUp':
                    moveUp.current = false;
                    break;
                case 'ArrowDown':
                    moveDown.current = false;
                    break;
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        document.addEventListener('keyup', handleKeyUp);

        const animate = () => {
            if (controlsRef.current) {
                const moveSpeed = 0.05;
                const strafeSpeed = 0.01;

                if (moveForward.current) controlsRef.current.moveForward(moveSpeed);
                if (moveBackward.current) controlsRef.current.moveForward(-moveSpeed);
                if (moveLeft.current) controlsRef.current.moveRight(-strafeSpeed);
                if (moveRight.current) controlsRef.current.moveRight(strafeSpeed);
                if (moveUp.current) camera.position.y += moveSpeed;
                if (moveDown.current) camera.position.y -= moveSpeed;
            }

            renderer.render(scene, camera);
            requestAnimationFrame(animate);
        };
        animate();

        return () => {
            mountRef.current?.removeChild(renderer.domElement);
            window.removeEventListener('resize', handleResize);
            document.removeEventListener('keydown', handleKeyDown);
            document.removeEventListener('keyup', handleKeyUp);
        };
    }, [mountRef]);

    return { cameraRef };
};
