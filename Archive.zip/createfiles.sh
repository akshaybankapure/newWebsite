#!/bin/bash

# Array of service names
services=(
    "CharacterConceptArt"
    "LocationConceptArt"
    "BuildingPropsVehicles"
    "StoryboardAnimatics"
    "MotionPoster"
    "TitleDesign"
    "VFX"
)

# Function to create HTML content
create_html_content() {
    local service_name="$1"
    cat << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service - ${service_name}</title>
</head>
<body>
    <h1>Service: ${service_name}</h1>
    <p>This is the page for ${service_name}. Content to be added.</p>
</body>
</html>
EOF
}

# Create HTML files for each service
for service in "${services[@]}"; do
    filename="Service-${service}.html"
    create_html_content "$service" > "$filename"
    echo "Created $filename"
done

echo "All service HTML files have been created."