<?php
include 'config.php';

$parent_id = $_GET['parent_id'];

function getSubMenuItems($conn, $parent_id) {
    $sql = "SELECT * FROM menu_items WHERE parent_id = ? ORDER BY id";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $parent_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $subMenuItems = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $subMenuItems[] = $row;
        }
    }

    return $subMenuItems;
}

$subMenuItems = getSubMenuItems($conn, $parent_id);

if (!empty($subMenuItems)) {
    echo '<table>';
    echo '<thead><tr><th>ID</th><th>Title</th><th>Link</th><th>Active</th><th>Has Children</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    foreach ($subMenuItems as $item) {
        echo '<tr>';
        echo '<td>' . $item['id'] . '</td>';
        echo '<td>' . $item['title'] . '</td>';
        echo '<td>' . $item['link'] . '</td>';
        echo '<td>' . ($item['is_active'] ? 'Yes' : 'No') . '</td>';
        echo '<td>' . ($item['has_children'] ? 'Yes' : 'No') . '</td>';
        echo '<td>
                <a href="admin_edit_menu_item.php?id=' . $item['id'] . '" class="button">Edit</a>
                <a href="admin_delete_menu_item.php?id=' . $item['id'] . '" class="button" onclick="return confirm(\'Are you sure?\')">Delete</a>
                <a href="admin_add_menu_item.php?parent_id=' . $item['id'] . '" class="button">Add Sub-Menu</a>
              </td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
} else {
    echo '<p>No sub-menus found for this menu.</p>';
}
?>
