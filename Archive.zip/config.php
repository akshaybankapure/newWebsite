<?php
$servername = "localhost";
$username = "akshay";
$password = "admin123"; 
// Xur2oA1pHPI9b49)
$dbname = "cms_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
